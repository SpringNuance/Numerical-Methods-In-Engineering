% Solution code of Assignmnet 1
clc;clear;
close all

Pt=3.5; %the given total pressure in[atm]
K=0.04; % given reaction equilibrium constant
f=[0:0.001:1]; % possible range of mole fraction with a approperiate step size
y=K-f./(1-f).*sqrt(2*Pt./(2+f));
np=length(f);
y_0=zeros(np);
figure(1);plot(f,y,'r.',f,y_0,'--');% try different markers or line types
xlabel('f,i.e.[H_2O]');% try different label
ylabel('y');
H=figure(1);
filename='Assign_week_4_1_Plot';
savefig(H, filename);
print(H,'-djpeg',filename);% try different output format for the figure

figure(2);plot(f,y,'r.',f,y_0,'--');% try different markers or line types
xlabel('f, i.e.[H_2O]');
ylabel('y');xlim([0 0.2]);% try different limits for the axes
H=figure(2);
filename='Assign_week_4_1_Plot_Zoom';
savefig(H, filename);
print(H,'-djpeg',filename);% try different output format for the figure
